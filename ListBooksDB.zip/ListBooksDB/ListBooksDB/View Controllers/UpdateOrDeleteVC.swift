//
//  UpdateOrDeleteVC.swift
//  ListBooksDB
//
//  Created by Patel, Nirali Arvindbhai on 11/3/19.
//  Copyright © 2019 Patel, Nirali Arvindbhai. All rights reserved.
//

import UIKit

class UpdateOrDeleteVC: UIViewController {

    var cid = ""
    
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblAuthor: UILabel!
    @IBOutlet weak var lblSubName: UILabel!
    @IBOutlet weak var lblDueDate: UILabel!
    
    @IBOutlet weak var txtTitle: UITextField!
    @IBOutlet weak var txtAuthor: UITextField!
    @IBOutlet weak var txtSubName: UITextField!
    @IBOutlet weak var txtDueDate: UITextField!
    
    var oldRecord: NSArray!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        txtTitle.becomeFirstResponder()
        
            lblTitle.text = "Title:"
             lblAuthor.text = "Author:"
             lblSubName.text = "SubjectName:"
             lblDueDate.text = "DueDate:"
        
        var eachDetail = BooksCRUD().fetchdetail(cid: cid as NSString)
        txtTitle.text = eachDetail[0] as? String
        txtAuthor.text = eachDetail[1] as? String
        txtSubName.text = eachDetail[2] as? String
        txtDueDate.text = eachDetail[3] as? String
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func btnUpdate(_ sender: Any) {
        dismiss(animated: true, completion: nil)
        
        var title:NSString = txtTitle?.text as! NSString
         var author:NSString = txtAuthor?.text as! NSString
         var sub_name:NSString = txtSubName?.text as! NSString
        var due_date:NSString = txtDueDate?.text as! NSString
         BooksCRUD().update( oldrecord: oldRecord, newrecord: NSArray(objects: title,author,sub_name,due_date))
        
    }
    
    @IBAction func btnDelete(_ sender: Any) {
        dismiss(animated: true, completion: nil)
        
        var title:NSString = txtTitle?.text as! NSString
        var author:NSString = txtAuthor?.text as! NSString
        var sub_name:NSString = txtSubName?.text as! NSString
        var due_date:NSString = txtDueDate?.text as! NSString
        
        var record:NSArray = NSArray()
        record = NSArray(objects: title,author,sub_name,due_date)
        BooksCRUD().delete(record: record)
        
    }
}
