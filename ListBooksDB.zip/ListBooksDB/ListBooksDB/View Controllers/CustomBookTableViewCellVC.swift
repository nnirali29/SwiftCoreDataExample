//
//  CustomBookTableViewCellVC.swift
//  ListBooksDB
//
//  Created by Patel, Nirali Arvindbhai on 11/3/19.
//  Copyright © 2019 Patel, Nirali Arvindbhai. All rights reserved.
//

import UIKit

class CustomBookTableViewCellVC: UITableViewCell {
//var getAll = BooksCRUD().fetchall()
    
    @IBOutlet weak var lblBookTitle: UILabel!
    
    @IBOutlet weak var lblDueDate: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        /*
        var d = Books()
                            // d = getAll as! Books
                         //   let recordObj = NSEntityDescription.entity(forEntityName: "Books", in: context)!
                         //  let book = NSManagedObject(entity: recordObj, insertInto: context)
       // let d = getAll.add(IndexPath.self)
        let b1 : NSString = d.title as! NSString
        let b2 :NSString = d.author as! NSString
         let b3 :NSString = d.subject_name as! NSString
        let b4 :NSString = d.due_date as! NSString
        
        lblBookTitle.text = b1 as String
        lblDueDate.text = b4 as String
 */
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }

}
