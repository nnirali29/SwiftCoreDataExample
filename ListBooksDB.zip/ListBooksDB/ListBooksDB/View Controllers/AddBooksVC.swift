//
//  AddBooksVC.swift
//  ListBooksDB
//
//  Created by Patel, Nirali Arvindbhai on 11/3/19.
//  Copyright © 2019 Patel, Nirali Arvindbhai. All rights reserved.
//

import UIKit

class AddBooksVC: UIViewController {
    
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblAuthor: UILabel!
    @IBOutlet weak var lblSubName: UILabel!
    @IBOutlet weak var lblDueDate: UILabel!
    @IBOutlet weak var txtTitle: UITextField!
    @IBOutlet weak var txtAuthor: UITextField!
    @IBOutlet weak var txtSubName: UITextField!
    @IBOutlet weak var txtDueDate: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
         txtTitle.becomeFirstResponder()
       
        lblTitle.text = "Title:"
         lblAuthor.text = "Author:"
         lblSubName.text = "Subject Name:"
         lblDueDate.text = "Due Date:"
    }
    
    @IBAction func btnAdd(_ sender: Any) {
        
      dismiss(animated: true, completion: nil)
        
       var title : NSString = txtTitle?.text as! NSString
         var author : NSString = txtAuthor?.text as! NSString
         var sub_name : NSString = txtSubName?.text as! NSString
         var due_date : NSString = txtDueDate?.text as! NSString
       
        var record : NSArray = NSArray()
         record = NSArray(objects: title,author,sub_name,due_date)
        BooksCRUD().addline(record: record)
    }
    // MARK: - Navigation
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
               var title : NSString = txtTitle?.text as! NSString
          var author : NSString = txtAuthor?.text as! NSString
          var sub_name : NSString = txtSubName?.text as! NSString
          var due_date : NSString = txtDueDate?.text as! NSString
        
         var record : NSArray = NSArray()
          record = NSArray(objects: title,author,sub_name,due_date)
         BooksCRUD().addline(record: record)
    }
}
