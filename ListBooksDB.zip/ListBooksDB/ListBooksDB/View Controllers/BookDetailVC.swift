//
//  BookDetailVC.swift
//  ListBooksDB
//
//  Created by Patel, Nirali Arvindbhai on 11/3/19.
//  Copyright © 2019 Patel, Nirali Arvindbhai. All rights reserved.
//

import UIKit

class BookDetailVC: UIViewController {

    var cid = ""
    var cidpass = ""
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblAuthor: UILabel!
    @IBOutlet weak var lblSubName: UILabel!
    @IBOutlet weak var lblDueDate: UILabel!
    
    @IBOutlet weak var txtTitle: UITextField!
    @IBOutlet weak var txtAuthor: UITextField!
    @IBOutlet weak var txtSubName: UITextField!
    @IBOutlet weak var txtDueDate: UITextField!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        txtTitle.isUserInteractionEnabled = false
        txtAuthor.isUserInteractionEnabled = false
        txtSubName.isUserInteractionEnabled = false
        txtDueDate.isUserInteractionEnabled = false
        
        lblTitle.text = "Title:"
        lblAuthor.text = "Author:"
        lblSubName.text = "SubjectName:"
        lblDueDate.text = "DueDate:"
        
        var eachDetail = BooksCRUD().fetchdetail(cid: cid as NSString)
        cidpass = eachDetail[0] as! String
        txtTitle.text = eachDetail[0] as? String
        txtAuthor.text = eachDetail[1] as? String
        txtSubName.text = eachDetail[2] as? String
        txtDueDate.text = eachDetail[3] as? String
    }
    // MARK: - Navigation
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if segue.identifier == "DetailToUpdate"{
            if let updateVC = segue.destination as? UpdateOrDeleteVC{
                updateVC.cid = cidpass
                print("Coming in details to update ==== ")
                updateVC.oldRecord = NSArray(objects: txtTitle.text, txtAuthor.text,txtSubName.text,txtDueDate.text)
            }
        }
    }

    @IBAction func btnUpdateOrDelete(_ sender: Any) {
        
        performSegue(withIdentifier: "DetailToUpdate", sender: self)
    }
    
    
}
