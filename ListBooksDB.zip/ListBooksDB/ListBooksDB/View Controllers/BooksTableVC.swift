//
//  BooksTableVC.swift
//  ListBooksDB
//
//  Created by Patel, Nirali Arvindbhai on 11/2/19.
//  Copyright © 2019 Patel, Nirali Arvindbhai. All rights reserved.
//

import UIKit
import CoreData


class BooksTableVC: UITableViewController {

    var getAll: NSMutableArray!
    var cidpass = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
       
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
        print("Calling from viewDidLoad")
        getAll = BooksCRUD().fetchall()
    }
//    override func viewDidAppear(_ animated: Bool) {
//        super.viewDidAppear(true)
//          let getAll = BooksCRUD().fetchall()
//        self.tableView.reloadData()
//    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        //return 10
        print("Count = ", getAll.count)
       return getAll.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CellIdentifier", for: indexPath) as! CustomBookTableViewCellVC

        var d : ListBooksDB = getAll[indexPath.row] as! ListBooksDB
        var title : NSString = d.title as! NSString
        var author : NSString = d.author as! NSString
        var sub_name : NSString = d.sub_name as! NSString
        var due_date : NSString = d.due_date as! NSString
        
        cell.lblBookTitle.text = title as String
        cell.lblDueDate.text = due_date as String
        
        print("Title = ", title)
        
        //   d = getAll[indexPath.row] as! Books
        
        // Configure the cell...
        cell.accessoryType = UITableViewCell.AccessoryType.disclosureIndicator
        return cell
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
          var d1 : ListBooksDB = getAll[indexPath.row] as! ListBooksDB
        var pass : NSString = d1.title as! NSString
        cidpass = pass as String
        
        
        
        performSegue(withIdentifier: "ListToDetail", sender: self)
        
        
        
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if segue.identifier == "ListToDetail"{
            if let detailVC = segue.destination as? BookDetailVC{
                detailVC.cid = cidpass
            }
        }
    }
    
    

//    @IBAction func btnAdd(_ sender: Any) {
//        performSegue(withIdentifier: "ListToAdd", sender: self)
//   }
    
    @IBAction func unwindAddSegue(_ sender: UIStoryboardSegue) {
        print("Calling from unwindAddSegue")
        getAll = BooksCRUD().fetchall()
        print("Reloading Data..")
        tableView.reloadData()
    }
    
    @IBAction func unwindDeleteSegue(_ sender: UIStoryboardSegue) {
        print("Calling from unwindDeleteSegue")
        getAll = BooksCRUD().fetchall()
        print("Reloading Data..")
        tableView.reloadData()
    }
    
    @IBAction func unwindUpdateSegue(_ sender: UIStoryboardSegue) {
        print("Calling from unwindUpdateSegue")
        getAll = BooksCRUD().fetchall()
        print("Reloading Data..")
        tableView.reloadData()
    }
}
